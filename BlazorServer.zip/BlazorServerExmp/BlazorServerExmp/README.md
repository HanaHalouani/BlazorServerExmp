# BlazorServerPersonApp
CRUD Blazor Server to add / get and update list of persons
